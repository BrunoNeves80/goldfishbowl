# Goldfish_fronten

# connect to Goldfish_backten (Node.js) at localhost:3001

# includes : Crude Login page that redirects to profile depending on user type (entrepreneur or investor)
