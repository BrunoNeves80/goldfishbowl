﻿using System.Runtime.InteropServices;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using MySqlConnector;

namespace Goldfish.Models
{
    public class Mysqlconnector
    {
        
}